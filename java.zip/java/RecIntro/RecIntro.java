package RecIntro;
import RecommendFactory.RecommendFactory;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.eval.IRStatistics;
import org.apache.mahout.cf.taste.eval.RecommenderBuilder;
import org.apache.mahout.cf.taste.eval.RecommenderEvaluator;
import org.apache.mahout.cf.taste.eval.RecommenderIRStatsEvaluator;
import org.apache.mahout.cf.taste.impl.common.LongPrimitiveIterator;
import org.apache.mahout.cf.taste.impl.eval.AverageAbsoluteDifferenceRecommenderEvaluator;
import org.apache.mahout.cf.taste.impl.eval.GenericRecommenderIRStatsEvaluator;
import org.apache.mahout.cf.taste.impl.model.file.FileDataModel;
import org.apache.mahout.cf.taste.impl.neighborhood.NearestNUserNeighborhood;
import org.apache.mahout.cf.taste.impl.recommender.ClusterSimilarity;
import org.apache.mahout.cf.taste.impl.recommender.GenericItemBasedRecommender;
import org.apache.mahout.cf.taste.impl.recommender.GenericUserBasedRecommender;
import org.apache.mahout.cf.taste.impl.recommender.knn.NonNegativeQuadraticOptimizer;
import org.apache.mahout.cf.taste.impl.recommender.svd.ALSWRFactorizer;
import org.apache.mahout.cf.taste.impl.similarity.PearsonCorrelationSimilarity;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.neighborhood.UserNeighborhood;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.recommender.Recommender;
import org.apache.mahout.cf.taste.similarity.ItemSimilarity;
import org.apache.mahout.cf.taste.similarity.UserSimilarity;
import org.apache.mahout.common.RandomUtils;
 
class RecIntro {
    public void processfiles(String strRecType, UserSimilarity USimi, DataModel model,String strfilePSnames,String strOutFile,int NEIGHBORHOOD_NUM,int RECOMMENDER_NUM) throws FileNotFoundException, TasteException, IOException {
                UserNeighborhood neighborhoodUserbased = new NearestNUserNeighborhood( NEIGHBORHOOD_NUM, USimi, model );

                Recommender recommender = new GenericUserBasedRecommender( model, neighborhoodUserbased, USimi );
           
                //for mapping real user-item
                FileInputStream fileIn = new FileInputStream(strfilePSnames);
                InputStreamReader reader = new InputStreamReader(fileIn);
                BufferedReader bufReader = new BufferedReader(reader);
                String strLine;
                FileWriter writer = new FileWriter(strOutFile);
                writer.write("");//seems it is not necessary
                //save to table
                //map user id to user name
                List<String[]> solutionsUser = new ArrayList<String[]>();
                while ((strLine = bufReader.readLine()) != null)
                {
                    String[] toks = strLine.split(",");                   
                    {          
                    String[] userArr  = new String[2];
                    userArr[0] = toks[0];
                    userArr[1] = toks[3];
                    solutionsUser.add(userArr);
                    }                      
                }
                //map item id to item name                              
                File fileForItem = new File(strfilePSnames);
                FileInputStream fileInItem = new FileInputStream(fileForItem);
                InputStreamReader readerItem = new InputStreamReader(fileInItem);
                BufferedReader bufReaderItem = new BufferedReader(readerItem);
                BufferedReader bfForItem = new BufferedReader(bufReaderItem);
                String strLineItem;
                List<String[]> topicsItem = new ArrayList<String[]>();
                while ((strLineItem = bfForItem.readLine()) != null)
                {
                    String[] toks = strLineItem.split(",");                    
                    {          
                    String[] itemArr  = new String[2];
                    itemArr[0] = toks[1];
                    itemArr[1] = toks[4];
                    topicsItem.add(itemArr);
                    }
                }
      for (LongPrimitiveIterator iterator = model.getUserIDs(); iterator.hasNext();)
      {
          long userId = iterator.nextLong();
          List<RecommendedItem> itemRecommendations = recommender.recommend(userId, RECOMMENDER_NUM);
 
          if (itemRecommendations.isEmpty())
          {
            
          }
          else
          {
              // Display the list of recommendations
              for (RecommendedItem recommendedItem : itemRecommendations)
              {
                
                //map user id to user name
                for (int i = 0; i < solutionsUser.size(); i++)
                {
                    String[] toks = solutionsUser.get(i);
                    long l = Long.parseLong(toks[0]);//hard code, idx0: user Id
                    if (userId == l)
                    {
                    writer.append(Long.toString(l));//user id
                    writer.append(',');
                    writer.append(toks[1]);//user/solution name
                    writer.append(',');
                    break;
                    }
                }
                for (int i = 0; i < topicsItem.size(); i++)
                {
                    String[] toksi = topicsItem.get(i);
                    long l = Long.parseLong(toksi[0]);//hard code, idx1: item Id
                    if (recommendedItem.getItemID() == l)
                    {          
                    writer.append(Long.toString(l));//item id
                    writer.append(',');
                    writer.append(toksi[1]);//item/problem name
                    writer.append(',');
                    String s = Float.toString(recommendedItem.getValue());                  
                    writer.append(s);//value
                    writer.append('\n');
                    break;
                    }
                }  
 //end write recommendation to file
              }            
              
              
          }
                    writer.flush();
      }
      writer.close();
    }
 //=======================item based======================================================
    public void processfiles(String strRecType, ItemSimilarity ISimi, DataModel model,String strfilePSnames,String strOutFile,int NEIGHBORHOOD_NUM,int RECOMMENDER_NUM) throws FileNotFoundException, TasteException, IOException {
                 Recommender recommender = new GenericItemBasedRecommender( model, ISimi);
                //for mapping real user-item
                FileInputStream fileIn = new FileInputStream(strfilePSnames);
                InputStreamReader reader = new InputStreamReader(fileIn);
                BufferedReader bufReader = new BufferedReader(reader);
                String strLine;
                FileWriter writer = new FileWriter(strOutFile);
                writer.write("");//seems it is not necessary
                //save to table
                //map user id to user name
                List<String[]> solutionsUser = new ArrayList<String[]>();
                while ((strLine = bufReader.readLine()) != null)
                {
                    String[] toks = strLine.split(",");                   
                    {          
                    String[] userArr  = new String[2];
                    userArr[0] = toks[0];
                    userArr[1] = toks[3];
                    solutionsUser.add(userArr);
                    }                      
                }
                //map item id to item name                              
                File fileForItem = new File(strfilePSnames);
                FileInputStream fileInItem = new FileInputStream(fileForItem);
                InputStreamReader readerItem = new InputStreamReader(fileInItem);
                BufferedReader bufReaderItem = new BufferedReader(readerItem);
                BufferedReader bfForItem = new BufferedReader(bufReaderItem);
                String strLineItem;
                List<String[]> topicsItem = new ArrayList<String[]>();
                while ((strLineItem = bfForItem.readLine()) != null)
                {
                    String[] toks = strLineItem.split(",");                    
                    {          
                    String[] itemArr  = new String[2];
                    itemArr[0] = toks[1];
                    itemArr[1] = toks[4];
                    topicsItem.add(itemArr);
                    }
                }
      for (LongPrimitiveIterator iterator = model.getUserIDs(); iterator.hasNext();)
      {
          long userId = iterator.nextLong();
          List<RecommendedItem> itemRecommendations = recommender.recommend(userId, RECOMMENDER_NUM);
 
          if (itemRecommendations.isEmpty())
          {
            
          }
          else
          {
              // Display the list of recommendations
              for (RecommendedItem recommendedItem : itemRecommendations)
              {
                
                //map user id to user name
                for (int i = 0; i < solutionsUser.size(); i++)
                {
                    String[] toks = solutionsUser.get(i);
                    long l = Long.parseLong(toks[0]);//hard code, idx0: user Id
                    if (userId == l)
                    {
                    writer.append(Long.toString(l));//user id
                    writer.append(',');
                    writer.append(toks[1]);//user/solution name
                    writer.append(',');
                    break;
                    }
                }
                for (int i = 0; i < topicsItem.size(); i++)
                {
                    String[] toksi = topicsItem.get(i);
                    long l = Long.parseLong(toksi[0]);//hard code, idx1: item Id
                    if (recommendedItem.getItemID() == l)
                    {          
                    writer.append(Long.toString(l));//item id
                    writer.append(',');
                    writer.append(toksi[1]);//item/problem name
                    writer.append(',');
                    String s = Float.toString(recommendedItem.getValue());                  
                    writer.append(s);//value
                    writer.append('\n');
                    break;
                    }
                }  
 //end write recommendation to file
              }            
              
              
          }
                    writer.flush();
      }
      writer.close();
    }
    //============for test evaluation====================
    
public static int eval(int RECOMMENDER_NUM) throws TasteException, IOException {
        DataModel dataModel = new FileDataModel( new File( "simple.csv" ) );        
        userLoglikelihood(dataModel,RECOMMENDER_NUM);
        return 1;
    }


public static RecommenderBuilder userLoglikelihood(DataModel dataModel,int RECOMMENDER_NUM) throws TasteException, IOException {
        System.out.println("example of userLoglikelihood");
        UserSimilarity userSimilarity = RecommendFactory.userSimilarity(RecommendFactory.SIMILARITY.LOGLIKELIHOOD, dataModel);
       
        UserNeighborhood userNeighborhood = RecommendFactory.userNeighborhood(RecommendFactory.NEIGHBORHOOD.NEAREST, userSimilarity, dataModel, 20);
        RecommenderBuilder recommenderBuilder = RecommendFactory.userRecommender(userSimilarity, userNeighborhood, false);

        RecommendFactory.evaluate(RecommendFactory.EVALUATOR.AVERAGE_ABSOLUTE_DIFFERENCE, recommenderBuilder, null, dataModel, 0.5);//lhx changed from 0.7->0.5
        RecommendFactory.statsEvaluator(recommenderBuilder, null, dataModel, RECOMMENDER_NUM);
        return recommenderBuilder;
    }

public Recommender buildRecommender(DataModel model) throws TasteException {
UserSimilarity similarity = new PearsonCorrelationSimilarity (model);
UserNeighborhood neighborhood = new NearestNUserNeighborhood (2, similarity, model);
return
new GenericUserBasedRecommender (model, neighborhood, similarity);
}

///////////





    
//        public static void main(String[] args) throws Exception {  
//            RecIntro myRec = new RecIntro();
//            int NEIGHBORHOOD_NUM = 50;
//            List<Integer> intlistNumRec =  new ArrayList<Integer>();
//            intlistNumRec.add(2);
//            intlistNumRec.add(5);
//            intlistNumRec.add(10);
//
//            List<String> strlistMetricfileSS =  new ArrayList<String>();
//            //"ss"
//            //"SolutionsVSproblems"
//            strlistMetricfileSS.add("-occ.csv");
//            strlistMetricfileSS.add("-con.csv");
//            strlistMetricfileSS.add("-ifidf.csv");
//            
//            int iMetr = 0;
//            while (iMetr < strlistMetricfileSS.size()) {//for to-be-processed files: ss.csv and p-s-names files
//                    System.out.println(strlistMetricfileSS.get(iMetr));
//                    DataModel model = new FileDataModel( new File( "ss"+strlistMetricfileSS.get(iMetr) ) );
//                    UserSimilarity  usersimilarityLogLikelihood=(UserSimilarity) RecommendFactory.userSimilarity(RecommendFactory.SIMILARITY.LOGLIKELIHOOD, model);                    
//                    int iNRed = 0;
//                    while (iNRed < intlistNumRec.size()) {//for outputfilename
//                            System.out.println(intlistNumRec.get(iNRed));
//
//                            myRec.processfiles("userbased", usersimilarityLogLikelihood, model, "SolutionsVSproblems"+strlistMetricfileSS.get(iMetr), "UserLOGLIKELIHOOD-"+Integer.toString(intlistNumRec.get(iNRed))+strlistMetricfileSS.get(iMetr), NEIGHBORHOOD_NUM, intlistNumRec.get(iNRed));                            
//                            iNRed++;
//                    } 
//                    
//                    UserSimilarity userPearsonCorrelation = new PearsonCorrelationSimilarity( model );
//                    iNRed = 0;
//                    while (iNRed < intlistNumRec.size()) {//for outputfilename
//                            System.out.println(intlistNumRec.get(iNRed));
//
//                            myRec.processfiles("userbased", usersimilarityLogLikelihood, model, "SolutionsVSproblems"+strlistMetricfileSS.get(iMetr), "userPearsonCorrelation-"+Integer.toString(intlistNumRec.get(iNRed))+strlistMetricfileSS.get(iMetr), NEIGHBORHOOD_NUM, intlistNumRec.get(iNRed));                            
//                            iNRed++;
//                    } 
//                    //================haixia start============================
//                    UserSimilarity  usersimilarityCITYBLOCK=(UserSimilarity) RecommendFactory.userSimilarity(RecommendFactory.SIMILARITY.CITYBLOCK, model);                    
//                    iNRed = 0;
//                    while (iNRed < intlistNumRec.size()) {//for outputfilename
//                            System.out.println(intlistNumRec.get(iNRed));
//                            //public void processfiles(String strRecType, UserSimilarity USimi, DataModel model,String strfilePSnames,String strOutFile,int NEIGHBORHOOD_NUM,int RECOMMENDER_NUM) throws FileNotFoundException, TasteException, IOException {
//                            myRec.processfiles("userbased", usersimilarityCITYBLOCK, model, "SolutionsVSproblems"+strlistMetricfileSS.get(iMetr), "UserCityBlock-"+Integer.toString(intlistNumRec.get(iNRed))+strlistMetricfileSS.get(iMetr), NEIGHBORHOOD_NUM, intlistNumRec.get(iNRed));                            
//                            iNRed++;
//                    }  
//                    UserSimilarity  usersimilarityTANIMOTO=(UserSimilarity) RecommendFactory.userSimilarity(RecommendFactory.SIMILARITY.TANIMOTO, model);
//                    iNRed = 0;
//                    while (iNRed < intlistNumRec.size()) {//for outputfilename
//                            System.out.println(intlistNumRec.get(iNRed));
//                            
//                            myRec.processfiles("userbased", usersimilarityTANIMOTO, model, "SolutionsVSproblems"+strlistMetricfileSS.get(iMetr), "UserTANIMOTO-"+Integer.toString(intlistNumRec.get(iNRed))+strlistMetricfileSS.get(iMetr), NEIGHBORHOOD_NUM, intlistNumRec.get(iNRed));                            
//                            iNRed++;
//                    }  
//                    
//                    //===================item based =========================================
//                    ItemSimilarity  itemsimilarityLogLikelyhood=(ItemSimilarity) RecommendFactory.userSimilarity(RecommendFactory.SIMILARITY.LOGLIKELIHOOD, model);
//                    iNRed = 0;
//                    //processfiles(String strRecType, ItemSimilarity USimi, DataModel model,String strfilePSnames,String strOutFile,int NEIGHBORHOOD_NUM,int RECOMMENDER_NUM) throws FileNotFoundException, TasteException, IOException {
//                    while (iNRed < intlistNumRec.size()) {//for outputfilename
//                            System.out.println(intlistNumRec.get(iNRed));
//                            myRec.processfiles("itembased", itemsimilarityLogLikelyhood, model, "SolutionsVSproblems"+strlistMetricfileSS.get(iMetr), "ItemLOGLIKELIHOOD-"+Integer.toString(intlistNumRec.get(iNRed))+strlistMetricfileSS.get(iMetr), NEIGHBORHOOD_NUM, intlistNumRec.get(iNRed));                            
//                            iNRed++;
//                    }  
//                    ItemSimilarity  itemsimilarityCityBlock=(ItemSimilarity) RecommendFactory.userSimilarity(RecommendFactory.SIMILARITY.CITYBLOCK, model);
//                    iNRed = 0;
//                    while (iNRed < intlistNumRec.size()) {//for outputfilename
//                            System.out.println(intlistNumRec.get(iNRed));
//                            
//                            myRec.processfiles("itembased",itemsimilarityCityBlock, model, "SolutionsVSproblems"+strlistMetricfileSS.get(iMetr), "ItemCityBlock-"+Integer.toString(intlistNumRec.get(iNRed))+strlistMetricfileSS.get(iMetr), NEIGHBORHOOD_NUM, intlistNumRec.get(iNRed));                            
//                            iNRed++;
//                    }  
//                    ItemSimilarity  itemsimilarityTANIMOTO=(ItemSimilarity) RecommendFactory.userSimilarity(RecommendFactory.SIMILARITY.TANIMOTO, model);
//                    iNRed = 0;
//                    while (iNRed < intlistNumRec.size()) {//for outputfilename
//                            System.out.println(intlistNumRec.get(iNRed));
//                            
//                            myRec.processfiles("itembased",itemsimilarityTANIMOTO,model, "SolutionsVSproblems"+strlistMetricfileSS.get(iMetr), "ItemTANIMOTO-"+Integer.toString(intlistNumRec.get(iNRed))+strlistMetricfileSS.get(iMetr), NEIGHBORHOOD_NUM, intlistNumRec.get(iNRed));                            
//                            iNRed++;
//                    }  
//                    //================haixia end============================
//                    iMetr++;                    
//            }
//            
//            
//            
//           
//        }

 public static void main(String[] args) throws Exception {  
//            RecIntro myRec = new RecIntro();
//            myRec.eval(1);
            int RECOMMENDER_NUM = 2;
            RandomUtils.useTestSeed();
            DataModel model = new FileDataModel (new File("ingreid_dishid.csv"));//name2id//ingreid_dishid//home/ocean/Downloads/lhx/dataset/Scientific-doc-sum/sentiment-analaysis-scientific-doc//media/ocean/54af543d-1d9b-42ff-ab92-5551bd5467f1/home/khyx3lhi/Downloads/codes/mycode/innovationmachine/data/BBCIngre/crawl_bbc_ingre_dishes/cite_senti_rec.csv
            //==========demo2===================
            RecommenderIRStatsEvaluator evaluator = new GenericRecommenderIRStatsEvaluator ();
            RecommenderBuilder recommenderBuilder = new RecommenderBuilder() {            
            @Override
            public Recommender buildRecommender(DataModel model) throws TasteException {
            UserSimilarity similarity = new PearsonCorrelationSimilarity (model);
            UserNeighborhood neighborhood = new NearestNUserNeighborhood (2, similarity, model);
            return new GenericUserBasedRecommender (model, neighborhood, similarity);
                }
            };
            //========print recommendations==========================
            UserSimilarity similarity = new PearsonCorrelationSimilarity (model);
            UserNeighborhood neighborhood = new NearestNUserNeighborhood (2, similarity, model);
            Recommender recommender = new GenericUserBasedRecommender (model, neighborhood, similarity);
//            List<RecommendedItem> recommendations = recommender.recommend(1, 1);
            
            for (LongPrimitiveIterator iterator = model.getUserIDs(); iterator.hasNext();)
            {
            long userId = iterator.nextLong(); 
            List<RecommendedItem> itemRecommendations = recommender.recommend(userId, RECOMMENDER_NUM);
//            System.out.print("Recommend Succeed for this user. UserID---");
//            System.out.println(userId);
              // Display the list of recommendations
              for (RecommendedItem recommendedItem : itemRecommendations)
              {                  
                System.out.format("User Id: %d%n", userId);
                System.out.format("Recommened Item Id %d. Strength of the preference: %f%n", recommendedItem.getItemID(), recommendedItem.getValue());
                IRStatistics stats = evaluator.evaluate(recommenderBuilder, null, model, null, RECOMMENDER_NUM,
                GenericRecommenderIRStatsEvaluator.CHOOSE_THRESHOLD, 1.0);
                System.out.println(stats.getPrecision());
                System.out.println(stats.getRecall());
                System.out.println(stats);
              }
            }
          
//            for (RecommendedItem recommendation : recommendations) {
//            System.out.println("Recommendations:     ");
//            System.out.println(recommendation);
//            }
            //========end print recommendations======================
            IRStatistics stats = evaluator.evaluate(recommenderBuilder, null, model, null, 1,
            GenericRecommenderIRStatsEvaluator.CHOOSE_THRESHOLD, 1.0);
            System.out.println(stats.getPrecision());
            System.out.println(stats.getRecall());
            System.out.println(stats);
//            
//            //================demo 1==============
//            RecommenderEvaluator evaluator0 = new AverageAbsoluteDifferenceRecommenderEvaluator ();
//            RecommenderBuilder builder = new RecommenderBuilder() {
//            @Override
//            public Recommender buildRecommender(DataModel model)
//            throws TasteException {
//            UserSimilarity similarity = new PearsonCorrelationSimilarity (model);
//            UserNeighborhood neighborhood =
//            new NearestNUserNeighborhood (2, similarity, model);
//            return
//            new GenericUserBasedRecommender (model, neighborhood, similarity);
//                }
//            };
//            
//            double score = evaluator0.evaluate(builder, null, model, 0.7, 1.0);
//            System.out.println(score);
    }
}
