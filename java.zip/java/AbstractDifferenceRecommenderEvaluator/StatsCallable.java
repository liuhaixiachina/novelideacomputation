/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package AbstractDifferenceRecommenderEvaluator;

import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.mahout.cf.taste.impl.common.RunningAverageAndStdDev;

/**
 *
 * @author ocean
 */
class StatsCallable implements Callable<Void> {

    public StatsCallable(Callable<Void> callable, boolean logStats, RunningAverageAndStdDev timing, AtomicInteger noEstimateCounter) {
    }

    @Override
    public Void call() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
